//
//  main.m
//  SampleProject
//
//  Created by wanghuan on 13-1-9.
//  Copyright (c) 2013年 wanghuan. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
