//
//  AppDelegate.h
//  SampleProject
//
//  Created by wanghuan on 13-1-9.
//  Copyright (c) 2013年 wanghuan. All rights reserved.
//

#import <UIKit/UIKit.h>




@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (retain, nonatomic) UIWindow *window;

@property NSString *appId;
@property NSString *channelId;
@property NSString *userId;


@end
