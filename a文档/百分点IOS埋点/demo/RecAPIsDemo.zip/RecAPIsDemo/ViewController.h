//
//  ViewController.h
//  SimpleProject
//
//  Created by wanghuan on 13-1-9.
//  Copyright (c) 2013年 wanghuan. All rights reserved.
//

#import <UIKit/UIKit.h>



#import "BfdAgent.h"

@interface ViewController : UITableViewController<mobideaRecProtocol>
{

}
@end